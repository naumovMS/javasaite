package javax.mail;

public class Message {

	public static final String RecipientType = null;

}
